n = int(input('Digite um número n: '))

for i in range(1,n):
    if n % i == 0:
        print(i)