frase = input('Digite a frase: ')
resposta = ""

for letra in frase:
    if not letra in('aeiouAEIOU'):
        resposta += letra 
print(resposta)