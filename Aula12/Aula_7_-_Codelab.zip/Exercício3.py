def listaString(texto):
    print(texto.upper())
    return

listaString('Rumo à Análise de Dados')