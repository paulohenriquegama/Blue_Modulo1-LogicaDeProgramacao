from datetime import date 


def voto(nascimento):
    current_year = date.today().year
    idade = current_year - nascimento
    if idade < 16:
        return f"Com {idade} anos de idade: NEGADO"
    elif idade < 18 or idade >= 65:
        return f"Com {idade} anos de idade: OPCIONAL"
    elif idade< 65:
        return f"Com {idade} anos de idade: OBRIGATÓRIO"
    

ano_nasc = int(input("Em qual ano você nasceu? \n"))
print(voto(ano_nasc))