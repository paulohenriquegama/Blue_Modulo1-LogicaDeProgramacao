# Resolução

# Definimos a função que recebe um determinado número de noites e retorna o custo do hotel, onde cada noite equivale a R$ 140,00.
def custo_hotel(noites):
	return noites * 140


# Definimos a função que recebe um determinado nome de cidade e retorna o custo da passagem de avião para essa cidade.
def custo_aviao(cidade):
	custo = 0

	if cidade == "São Paulo":
		custo = 312.0
	elif cidade == "Porto Alegre":
		custo = 447.0
	elif cidade == "Recife":
		custo = 831.0
	elif cidade == "Manaus":
		custo = 986.0

	return custo


# Definimos a função que recebe um determinado número de dias e retorna o custo do aluguel de carro, onde cada dia equivale a R$ 40,00, aplicando um determinado desconto dependendo do número de dias que a pessoa utilizar o serviço.
def custo_carro(dias):
	custo = dias * 40

	if dias >= 7:
		custo -= 50
	elif dias >= 3:
		custo = custo - 20

	return custo


# Definimos a função que recebe todos os valores: 'noites, cidade, dias com o carro e o gasto extra' e retorna o custo total da viagem, calculando os valores com as respectivas funções declaradas anteriormente.
def custo_total(noites, cidade, dias_carro, gasto_extra):
	return custo_hotel(noites) + custo_aviao(cidade) + custo_carro(dias_carro) + gasto_extra


# Pegamos as informações digitadas pelo usuário.
noites = int(input("Quantas noitas você irá passar? "))
cidade = input("Para qual cidade você vai? ")
dias_carro = int(input("Quantos dias você usará o carro? "))
gasto_extra = float(input("Qual será o seu gasto extra?"))

# Passamos os valores digitados para a função que irá calcular o custo total da viagem.
custo = custo_total(noites, cidade, dias_carro, gasto_extra)

# Exibimos na tela o custo total da viagem, detalhando algumas informações digitadas anteriormente.
print("O custo total para ir para {}, ficar {} noites, usar o carro por {} dias e gastar R$ {:.2f} a mais é de R$ {:.2f}".format(cidade, noites, dias_carro, gasto_extra, custo))
