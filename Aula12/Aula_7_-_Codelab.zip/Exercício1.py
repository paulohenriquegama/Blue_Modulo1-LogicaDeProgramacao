def imprime_menor(a, b):
    if a < b:
        print(a)
    elif a > b:
        print(b)
    else:
        print("Os números são iguais.")


imprime_menor(10, 50)