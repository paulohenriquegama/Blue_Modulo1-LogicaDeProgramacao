def soma_maior_que_limite(a, b, limite):
    if a + b > limite:
        return True
    else:
        return False


print(soma_maior_que_limite(14, 5, 15))